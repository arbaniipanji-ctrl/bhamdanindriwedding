# Wedding Invitation V1

1. Buka `index.html` di browser untuk melihat undangan.
2. Ganti nama, tanggal, lokasi, dan teks placeholder di `index.html`.
3. Ganti tanggal countdown di `script.js` pada variabel `weddingDate`.
4. Untuk foto, ganti kotak "FOTO" dengan tag `<img>` dan file foto sendiri.
5. Untuk musik, simpan file `music.mp3` di folder yang sama lalu ubah:
   `<audio id="bgMusic" loop preload="none">`
   menjadi:
   `<audio id="bgMusic" loop preload="none" src="music.mp3">`

Catatan:
- Ini adalah V1/fondasi desain.
- Setelah isi dan foto final, website bisa di-deploy ke hosting agar punya link yang dapat dibagikan via WhatsApp/Instagram.
